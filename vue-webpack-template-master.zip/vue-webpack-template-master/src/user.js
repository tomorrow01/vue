/**
 * Created by willchen on 2017/12/12.
 */

let test = "test script";

