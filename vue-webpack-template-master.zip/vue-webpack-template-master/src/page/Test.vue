<template>
    <h1>test</h1>
</template>


<script>
    export default {
        data() {
            return {};
        },

        computed: {},

        methods: {},


    };
</script>


<style lang="sass" rel="stylesheet/scss" scoped>

</style>
