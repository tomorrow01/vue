<template>
    <h1>用户详情页</h1>
</template>


<script>
    import pub from "script/public";
    export default {
        data() {
            return {

            };
        },

        computed: {},

        methods: {},


    };
</script>


<style lang="sass" rel="stylesheet/scss" scoped>

</style>
