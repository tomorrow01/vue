/**
 * Created by willchen on 2017/8/21.
 */
import Axios from "../axios/index";

export default {
    state: {

    },
    getters: {

    },

    /* 状态变更 使用mutation*/
    mutations: {


    },

    /* ajax 请求使用action*/
    actions: {


    }
};