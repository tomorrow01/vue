/**
 * Created by willchen on 2017/12/28.
 */
let admin = {
    name    : "zzzzzzz",
    password: "123456"
};