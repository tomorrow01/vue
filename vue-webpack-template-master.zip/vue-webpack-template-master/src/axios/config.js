/**
 * Created by willchen on 2017/8/18.
 */

export default {
    baseURL        : "/",
    withCredentials: true,
    headers        : {


    }
};